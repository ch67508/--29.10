import sqlite3
import os

DB_NAME = 'birds.db'

def init_db():
    """Создаёт базу данных и таблицу, если они не существуют."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS birds (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            species TEXT NOT NULL,
            location TEXT,
            date_caught TEXT
        )
    ''')
    conn.commit()
    conn.close()

def add_bird(name, species, location=None, date_caught=None):
    """Добавляет новую птицу в базу."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO birds (name, species, location, date_caught)
        VALUES (?, ?, ?, ?)
    ''', (name, species, location, date_caught))
    conn.commit()
    bird_id = cursor.lastrowid
    conn.close()
    print(f"✅ Птица добавлена с ID: {bird_id}")

def view_birds():
    """Показывает все птицы из базы."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM birds')
    birds = cursor.fetchall()
    conn.close()
    
    if not birds:
        print("📭 Нет пойманных птиц.")
        return
    
    print("\n🦜 Пойманные птицы:")
    for bird in birds:
        print(f"ID: {bird[0]}, Имя: {bird[1]}, Вид: {bird[2]}, Место: {bird[3] or '—'}, Дата: {bird[4] or '—'}")

def update_bird(bird_id, name=None, species=None, location=None, date_caught=None):
    """Обновляет данные о птице по ID."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    # Получаем текущие данные
    cursor.execute('SELECT * FROM birds WHERE id = ?', (bird_id,))
    bird = cursor.fetchone()
    if not bird:
        print("❌ Птица с таким ID не найдена.")
        conn.close()
        return

    # Подготавливаем новые значения
    new_name = name if name else bird[1]
    new_species = species if species else bird[2]
    new_location = location if location else bird[3]
    new_date = date_caught if date_caught else bird[4]

    cursor.execute('''
        UPDATE birds
        SET name = ?, species = ?, location = ?, date_caught = ?
        WHERE id = ?
    ''', (new_name, new_species, new_location, new_date, bird_id))
    
    conn.commit()
    conn.close()
    print(f"✅ Птица с ID {bird_id} обновлена.")

def delete_bird(bird_id):
    """Удаляет птицу по ID."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('DELETE FROM birds WHERE id = ?', (bird_id,))
    if cursor.rowcount == 0:
        print("❌ Птица с таким ID не найдена.")
    else:
        print(f"🗑️ Птица с ID {bird_id} удалена.")
    conn.commit()
    conn.close()

def main_menu():
    """Главное меню приложения."""
    while True:
        print("\n" + "="*40)
        print("🦜 СИСТЕМА УЧЁТА ПОЙМАННЫХ ПТИЦ")
        print("="*40)
        print("1. Добавить птицу")
        print("2. Показать все птицы")
        print("3. Изменить данные птицы")
        print("4. Удалить птицу")
        print("0. Выход")
        choice = input("Выберите действие: ").strip()

        if choice == '1':
            name = input("Имя птицы: ").strip()
            species = input("Вид птицы: ").strip()
            location = input("Место поимки (опционально): ").strip() or None
            date = input("Дата поимки (опционально, например: 2025-04-05): ").strip() or None
            add_bird(name, species, location, date)

        elif choice == '2':
            view_birds()

        elif choice == '3':
            try:
                bird_id = int(input("Введите ID птицы для изменения: "))
                print("Оставьте поле пустым, чтобы не менять его.")
                name = input("Новое имя: ").strip() or None
                species = input("Новый вид: ").strip() or None
                location = input("Новое место: ").strip() or None
                date = input("Новая дата: ").strip() or None
                update_bird(bird_id, name, species, location, date)
            except ValueError:
                print("❌ Неверный ID. Введите число.")

        elif choice == '4':
            try:
                bird_id = int(input("Введите ID птицы для удаления: "))
                delete_bird(bird_id)
            except ValueError:
                print("❌ Неверный ID. Введите число.")

        elif choice == '0':
            print("👋 До свидания!")
            break

        else:
            print("❌ Неверный выбор. Попробуйте снова.")

if __name__ == "__main__":
    init_db()
    main_menu()